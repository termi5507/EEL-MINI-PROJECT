# Career Guidance (Frontend + Backend)

This repository contains a simple frontend (static HTML) and a Node + Express backend
that serves a comprehensive careers dataset for Science, Commerce, and Arts.

## Structure
- `frontend/` - static HTML/CSS/JS UI (index.html)
- `backend/` - Node + Express API with sample data
  - `server.js`
  - `package.json`
  - `data/careers.json`
- `.gitignore`
- `LICENSE` (MIT)

## Quick start (local)

### Backend
```bash
cd backend
npm install
npm run start
# Server will run at http://localhost:4000
```

### Frontend
Open `frontend/index.html` in your browser (or serve it via a static server).
The frontend can call the API at `http://localhost:4000/api/careers`.

## How to push to GitHub (one-time)
1. Create a new repository on GitHub (e.g., `career-guidance`).
2. Run:
```bash
git init
git add .
git commit -m "Initial commit: career guidance frontend + backend"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## Notes
- This is a sample starter. You can extend `data/careers.json` with more entries or connect a database.
- If you want, I can provide a GitHub Actions workflow to deploy the backend to platforms like Railway or Render.
