const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

const DATA_PATH = path.join(__dirname, "data", "careers.json");
function loadData() {
  try {
    const raw = fs.readFileSync(DATA_PATH, "utf8");
    return JSON.parse(raw);
  } catch (err) {
    console.error("Failed to load data:", err);
    return [];
  }
}

function jsonToCsv(items) {
  if (!Array.isArray(items)) items = [items];
  if (items.length === 0) return "";
  const headers = Object.keys(items[0]);
  const csvRows = [
    headers.join(","),
    ...items.map((row) =>
      headers
        .map((h) => {
          const val = row[h] === undefined || row[h] === null ? "" : String(row[h]);
          return `"\${val.replace(/"/g, '""')}"`;
        })
        .join(",")
    ),
  ];
  return csvRows.join("\n");
}

app.get("/api/careers", (req, res) => {
  const data = loadData();
  const { stream, q, page = 1, limit = 100, sort } = req.query;
  let list = data.slice();

  if (stream) {
    list = list.filter((c) => String(c.stream).toLowerCase() === String(stream).toLowerCase());
  }
  if (q) {
    const ql = q.toLowerCase();
    list = list.filter((c) =>
      [
        c.title,
        c.overview,
        c.stream,
        (c.exams || []).join(" "),
        (c.skills || []).join(" "),
        (c.educationPath || []).join(" "),
      ]
        .join(" ")
        .toLowerCase()
        .includes(ql)
    );
  }

  if (sort === "salary_desc") {
    list.sort((a, b) => {
      const n = (s) => {
        if (!s || !s.avgSalaryRange) return 0;
        const m = String(s.avgSalaryRange).match(/\d+/g);
        return m ? parseInt(m[0], 10) : 0;
      };
      return n(b) - n(a);
    });
  }

  const p = parseInt(page, 10);
  const l = parseInt(limit, 10);
  const start = (p - 1) * l;
  const paged = list.slice(start, start + l);

  res.json({
    total: list.length,
    page: p,
    limit: l,
    data: paged,
  });
});

app.get("/api/careers/:id", (req, res) => {
  const id = req.params.id;
  const data = loadData();
  const item = data.find((d) => d.id === id);
  if (!item) return res.status(404).json({ error: "Not found" });
  res.json(item);
});

app.get("/api/search", (req, res) => {
  const q = req.query.q || "";
  const stream = req.query.stream || "";
  req.query.limit = req.query.limit || 50;
  const data = loadData();
  let list = data.filter((c) => {
    if (stream && String(c.stream).toLowerCase() !== String(stream).toLowerCase()) return false;
    const hay = [c.title, c.overview, c.stream, (c.skills || []).join(" "), (c.exams || []).join(" ")].join(" ").toLowerCase();
    return hay.includes(String(q).toLowerCase());
  });
  res.json({ total: list.length, data: list.slice(0, Number(req.query.limit)) });
});

app.get("/api/export/csv", (req, res) => {
  const stream = req.query.stream;
  const data = loadData();
  let list = data;
  if (stream) list = list.filter((c) => String(c.stream).toLowerCase() === String(stream).toLowerCase());

  const flat = list.map((c) => ({
    id: c.id,
    stream: c.stream,
    title: c.title,
    overview: c.overview,
    exams: (c.exams || []).join("; "),
    preparationTips: (c.preparationTips || []).join(" | "),
    futureScope: c.futureScope,
    avgSalaryRange: c.avgSalaryRange,
    skills: (c.skills || []).join("; "),
    educationPath: (c.educationPath || []).join("; "),
    typicalEmployers: (c.typicalEmployers || []).join("; "),
    growthOutlook: c.growthOutlook || "",
  }));

  const csv = jsonToCsv(flat);
  res.setHeader("Content-Disposition", `attachment; filename="careers${stream ? "-" + stream : ""}.csv"`);
  res.setHeader("Content-Type", "text/csv");
  res.send(csv);
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true, timestamp: Date.now() });
});

app.use((req, res) => {
  res.status(404).json({ error: "Not found" });
});

app.listen(PORT, () => {
  console.log(`Career API running on http://localhost:\${PORT}`);
});
